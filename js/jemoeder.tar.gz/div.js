class Div extends Element {
    constructor(className, id) {
        super("div", className, id);
    }
}
