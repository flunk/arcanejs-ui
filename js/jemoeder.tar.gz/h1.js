class H1 extends Element {
    constructor(text) {
        super("h1");
      	this.setText(text);
    }
}