class Paragraph extends Element {
    constructor(text) {
        super("p");
      	this.setText(text);
    }
}