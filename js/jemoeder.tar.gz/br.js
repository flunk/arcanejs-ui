class Br extends Element {
    constructor() {
        super("br");
    }
}