class Span extends Element {
    constructor(className, id) {
        super("span", className, id);
    }
}