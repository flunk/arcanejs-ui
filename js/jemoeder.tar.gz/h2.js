class H2 extends Element {
    constructor(text) {
        super("h2");
      	this.setText(text);
    }
}