class H3 extends Element {
    constructor(text) {
        super("h3");
      	this.setText(text);
    }
}